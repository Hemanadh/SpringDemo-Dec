package org.cap.demo;

public class Student {
	
	private int studentid;
	private String studentName;
	private double fees;
	
	public Student(){}
	
	public Student(int studentid, String studentName, double fees) {
		super();
		this.studentid = studentid;
		this.studentName = studentName;
		this.fees = fees;
	}
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	@Override
	public String toString() {
		return "Student [studentid=" + studentid + ", studentName=" + studentName + ", fees=" + fees + "]";
	}
	
	

}
