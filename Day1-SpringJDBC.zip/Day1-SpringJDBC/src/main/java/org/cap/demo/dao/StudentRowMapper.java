package org.cap.demo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.demo.Student;
import org.springframework.jdbc.core.RowMapper;

public class StudentRowMapper implements RowMapper<Student>{

	public Student mapRow(ResultSet rs, int count) throws SQLException {
		Student student=new Student();
		student.setStudentid(rs.getInt("studid"));
		student.setStudentName(rs.getString("studentName"));
		student.setFees(rs.getDouble("fees"));
		return student;
	}

}
