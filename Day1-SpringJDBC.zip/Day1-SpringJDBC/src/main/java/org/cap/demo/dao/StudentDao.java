package org.cap.demo.dao;

import org.cap.demo.Student;

public interface StudentDao {

	public void createStudent(Student student);
	public Student getStudent(int studentId);
}
