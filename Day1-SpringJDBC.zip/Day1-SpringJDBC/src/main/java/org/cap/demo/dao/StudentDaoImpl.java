package org.cap.demo.dao;

import javax.sql.DataSource;

import org.cap.demo.Student;
import org.springframework.jdbc.core.JdbcTemplate;

public class StudentDaoImpl implements StudentDao{
	
	
	private JdbcTemplate jdbcTemp;
	private DataSource dataSource;
	
	public StudentDaoImpl(){}
	
	


	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemp = new JdbcTemplate(dataSource);
		
	}







	public void createStudent(Student student) {
		String sql="insert into students values(?,?,?)";
		
		jdbcTemp.update(sql, new Object[]{student.getStudentid(),
				student.getStudentName(),student.getFees()});
		
		System.out.println("Record Inserted");
		
	}




	public Student getStudent(int studentId) {
		String sql="select * from students where studid=?";
		
		Student student=jdbcTemp.queryForObject(sql,new StudentRowMapper() ,new Object[]{studentId});
		
		return student;
	}

}
