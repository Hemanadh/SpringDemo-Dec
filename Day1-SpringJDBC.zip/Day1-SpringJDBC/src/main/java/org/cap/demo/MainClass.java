package org.cap.demo;

import org.cap.demo.dao.StudentDaoImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("myBeans.xml");
		
		StudentDaoImpl daoImpl=(StudentDaoImpl)context.getBean("studentDao");
		
		/*Student student=new Student(3, "Jack", 1289);
		Student student1=new Student(2, "Jerry", 1299);
		Student student2=new Student(4, "Ram", 4500);
		Student student3=new Student(5, "Sam", 3456);
		
		daoImpl.createStudent(student);
		daoImpl.createStudent(student1);
		daoImpl.createStudent(student2);
		daoImpl.createStudent(student3);*/

		Student student=daoImpl.getStudent(4);
		
		System.out.println(student);
	}

}
