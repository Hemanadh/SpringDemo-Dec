package org.cap.service;

import java.util.List;

import org.cap.dao.EmployeeDao;
import org.cap.pojo.Department;
import org.cap.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeDao employeeDao;

	@Transactional
	public void createEmployee(Employee employee) {
		employeeDao.createEmployee(employee);
	}

	@Transactional
	public List<Department> getAllDepartments() {
		// TODO Auto-generated method stub
		return employeeDao.getAllDepartments();
	}

	@Transactional
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeDao.getAllEmployees();
	}

	@Transactional
	public void deleteEmployee(Integer empId) {
		employeeDao.deleteEmployee(empId);
	}

}
