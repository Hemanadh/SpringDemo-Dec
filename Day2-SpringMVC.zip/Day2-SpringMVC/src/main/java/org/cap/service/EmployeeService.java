package org.cap.service;

import java.util.List;

import org.cap.pojo.Department;
import org.cap.pojo.Employee;

public interface EmployeeService {
	public void createEmployee(Employee employee);
	public List<Department> getAllDepartments();
	public List<Employee> getAllEmployees();
	public void deleteEmployee(Integer empId);
}
