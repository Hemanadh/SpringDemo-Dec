package org.cap.pojo;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;


@Entity
@Table(name="cap_employee")
public class Employee {
	@Id
	@GeneratedValue
	private int empId;
	
	@NotEmpty(message="*Please enter Employee Name.")
	private String empName;
	
	@Range(min=12000,max=100000,message="*Salary should be between 12000 to 1Lak.")
	private double salary;
	
	@ManyToOne(cascade=CascadeType.REFRESH,fetch=FetchType.EAGER)
	private Department department;
	
	@NotEmpty(message="*Please enter Email Id.")
	@Email(message="*Please enter valid Email.")
	private String email;
	
	@Past(message="*Please enter past date for Date of birth.")
	private Date dob;
	
	
	public Employee(){}
	
	public Employee(int empId, String empName, double salary, Department department, String email, Date dob) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.department = department;
		this.email = email;
		this.dob = dob;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", department=" + department
				+ ", email=" + email + ", dob=" + dob + "]";
	}
	
	

}
