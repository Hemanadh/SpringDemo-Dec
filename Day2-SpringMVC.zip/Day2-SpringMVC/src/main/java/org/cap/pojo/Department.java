package org.cap.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="cap_department")
public class Department {
	
	@Id
	private int departId;
	private String departName;
	
	@OneToMany(fetch=FetchType.LAZY,cascade=CascadeType.REFRESH,
			mappedBy="department",targetEntity=Employee.class)
	private List<Employee> employees;
	
	public Department(){}
	
	public Department(int departId, String departName) {
		super();
		this.departId = departId;
		this.departName = departName;
	}
	public int getDepartId() {
		return departId;
	}
	public void setDepartId(int departId) {
		this.departId = departId;
	}
	public String getDepartName() {
		return departName;
	}
	public void setDepartName(String departName) {
		this.departName = departName;
	}
	
	
	
	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "Department [departId=" + departId + ", departName=" + departName + ", employees=" + employees + "]";
	}

	
	

}
