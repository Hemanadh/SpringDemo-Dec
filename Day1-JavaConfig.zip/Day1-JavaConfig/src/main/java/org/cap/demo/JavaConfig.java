package org.cap.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class JavaConfig {

	@Bean(name="emp")
	@Scope("prototype")
	public Employee getEmpBean(){
		return new Employee(1001, "Jack", 12000);
	}
	
	@Bean(name="address")
	public Address getAddressBean(){
		return new Address("12/B", "West Car St", "Pune");
	}
	
}
