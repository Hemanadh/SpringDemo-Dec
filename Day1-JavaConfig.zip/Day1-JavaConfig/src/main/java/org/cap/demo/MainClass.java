package org.cap.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(JavaConfig.class);

		Employee employee=(Employee)context.getBean("emp");
		
		Employee employee1=(Employee)context.getBean("emp");
		employee1.setEmpName("Tom");
		
		System.out.println(employee1);
		System.out.println(employee);
	}

}
